#ifndef DISPLAY_H
#define DISPLAY_H

#ifdef __cplusplus
extern "C" {
#endif

void display(void);

#ifdef __cplusplus
}
#endif

#endif /* DISPLAY_H */