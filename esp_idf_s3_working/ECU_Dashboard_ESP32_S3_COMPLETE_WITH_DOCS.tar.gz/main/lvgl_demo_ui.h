#ifndef LVGL_DEMO_UI_H
#define LVGL_DEMO_UI_H

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

void example_lvgl_demo_ui(lv_disp_t *disp);

#ifdef __cplusplus
}
#endif

#endif /* LVGL_DEMO_UI_H */