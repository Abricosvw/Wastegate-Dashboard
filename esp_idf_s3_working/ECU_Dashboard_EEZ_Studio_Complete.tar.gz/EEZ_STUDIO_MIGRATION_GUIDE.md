# ECU Dashboard Migration to EEZ Studio

## 🎯 Обзор миграции

Этот гайд поможет адаптировать проект ECU Dashboard с SquareLine Studio на **EEZ Studio** для более продвинутого UI развития и расширенной функциональности.

### Преимущества EEZ Studio для ECU Dashboard:
- ✓ **Flow-based programming** для сложной логики CAN-шины
- ✓ **Expression builder** для расчета параметров датчиков
- ✓ **Timeline анимации** для плавных переходов значений
- ✓ **Multi-screen поддержка** для расширения интерфейса
- ✓ **Built-in отладчик** с breakpoints
- ✓ **Open source** - полностью бесплатно

---

## 📋 Подготовка к миграции

### Шаг 1: Установка EEZ Studio

**Windows/macOS/Linux:**
1. Скачайте EEZ Studio с официального сайта: https://www.envox.eu/studio/
2. Или GitHub releases: https://github.com/eez-open/studio/releases
3. Установите и запустите EEZ Studio

### Шаг 2: Анализ текущей структуры проекта

**Текущие файлы SquareLine:**
```
main/ui/
├── ui.c                    # Основной UI файл
├── ui.h                    # Заголовочные файлы
├── ui_helpers.c            # Вспомогательные функции
├── ui_helpers.h            # Заголовки помощников
├── ui_events.h             # Обработчики событий
└── screens/
    ├── ui_Screen1.c        # Главный экран с датчиками
    └── ui_Screen1.h        # Заголовочный файл
```

**Что нужно адаптировать:**
- 6 круговых датчиков (MAP, Wastegate, TPS, RPM, Target Boost, TCU Status)
- Цветовые схемы для каждого датчика
- Анимации изменения значений
- CAN-данные интеграция

---

## 🛠️ Создание проекта в EEZ Studio

### Шаг 3: Новый LVGL проект

1. **Создание проекта:**
   - File → New Project
   - Выберите "LVGL" template
   - Project name: "ECU_Dashboard"
   - Target: ESP32-S3 (800x480)

2. **Настройка дисплея:**
   ```
   Width: 800px
   Height: 480px
   Color depth: 16bit (RGB565)
   DPI: 100
   ```

3. **Настройка themes:**
   - Background: Dark automotive theme
   - Primary color: #00D4FF (automotive blue)
   - Secondary: #FF6B35 (warning orange)

### Шаг 4: Создание UI компонентов

**Структура экранов:**
```
Screens/
├── MainScreen              # Основной экран с датчиками
│   ├── MapPressureGauge    # Датчик MAP давления
│   ├── WastegateGauge      # Датчик положения вестгейта
│   ├── TpsGauge            # Датчик TPS
│   ├── RpmGauge            # Датчик оборотов
│   ├── TargetBoostGauge    # Датчик целевого наддува
│   └── TcuStatusLed        # LED статуса TCU
└── SettingsScreen          # Экран настроек (опционально)
```

### Шаг 5: Создание датчиков

**1. MAP Pressure Gauge (Синий):**
```
Component Type: Arc gauge
Properties:
- Min value: 100
- Max value: 250
- Current value: Variable "map_pressure"
- Color: #00D4FF
- Background: Dark gray
- Needle: White
- Units: "kPa"
- Animation: Smooth transition 200ms
```

**2. Wastegate Position (Зеленый):**
```
Component Type: Arc gauge  
Properties:
- Min value: 0
- Max value: 100
- Current value: Variable "wastegate_pos"
- Color: #00FF88
- Units: "%"
- Animation: Smooth transition 150ms
```

**3. TPS Position (Желтый):**
```
Component Type: Arc gauge
Properties:
- Min value: 0
- Max value: 100
- Current value: Variable "tps_position"
- Color: #FFD700
- Units: "%"
- Animation: Quick response 100ms
```

**4. Engine RPM (Оранжевый):**
```
Component Type: Arc gauge
Properties:
- Min value: 0
- Max value: 7000
- Current value: Variable "engine_rpm"
- Color: #FF6B35
- Red zone: 6000-7000 (danger)
- Units: "RPM"
- Animation: Smooth 250ms
```

**5. Target Boost (Желтый):**
```
Component Type: Arc gauge
Properties:
- Min value: 100
- Max value: 250
- Current value: Variable "target_boost"
- Color: #FFD700
- Units: "kPa"
- Animation: Slow transition 300ms
```

**6. TCU Status LED:**
```
Component Type: LED indicator + Label
Properties:
- States: OK (Green), WARNING (Yellow), ERROR (Red)
- Current state: Variable "tcu_status"
- Labels: "TCU OK", "TCU WARN", "TCU ERROR"
- Blink pattern: ERROR state blinks
```

---

## 📊 Настройка переменных и данных

### Шаг 6: Определение переменных

**Global Variables в EEZ Studio:**
```cpp
// CAN Data Variables
int16_t map_pressure = 100;      // 100-250 kPa
int8_t  wastegate_pos = 0;       // 0-100%
int8_t  tps_position = 0;        // 0-100%
int16_t engine_rpm = 0;          // 0-7000 RPM
int16_t target_boost = 100;      // 100-250 kPa
int8_t  tcu_status = 0;          // 0=OK, 1=WARN, 2=ERROR

// Animation state variables
bool data_received = false;
uint32_t last_can_update = 0;
```

### Шаг 7: Flow-based логика

**1. CAN Data Reception Flow:**
```
[CAN Message Received] → [Parse Data] → [Update Variables] → [Trigger Animation]
```

**2. Data Validation Flow:**
```
[Receive Value] → [Range Check] → [Error Handling] → [Display Update]
```

**3. Animation Flow:**
```
[Value Change] → [Calculate Delta] → [Smooth Transition] → [Update Display]
```

---

## 🔧 Генерация и интеграция кода

### Шаг 8: Export C++ кода

1. **Compile project** (кнопка "wrench" в EEZ Studio)
2. **Export files** в папку проекта:
   ```
   Generated files:
   ├── screens.h/c         # UI экраны
   ├── ui.h/c              # Основной UI
   ├── vars.h/c            # Переменные
   ├── actions.h/c         # Обработчики событий
   └── assets.h/c          # Ресурсы (шрифты, изображения)
   ```

### Шаг 9: Интеграция с ESP32-S3

**Обновление main.c:**
```c
#include "ui.h"              // EEZ Studio UI
#include "vars.h"            // Переменные EEZ

// В main() после инициализации LVGL:
void app_main(void)
{
    // ... LCD и LVGL инициализация ...
    
    // Инициализация EEZ Studio UI
    ui_init();
    
    // Создание задач
    xTaskCreatePinnedToCore(can_receive_task, "CAN_RX", 4096, NULL, 5, NULL, 1);
    xTaskCreatePinnedToCore(ui_update_task, "UI_UPDATE", 4096, NULL, 4, NULL, 0);
    
    // Основной LVGL цикл
    while (1) {
        lv_timer_handler();
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}
```

**Обновление CAN обработчика:**
```c
void update_engine_gauges(uint16_t rpm, uint16_t map, uint8_t tps)
{
    // Обновление переменных EEZ Studio
    set_var_engine_rpm(rpm);
    set_var_map_pressure(map);
    set_var_tps_position(tps);
    
    // Вызов обновления UI
    ui_update();
    
    data_received = true;
    last_can_update = xTaskGetTickCount();
}

void update_boost_gauges(uint8_t wastegate, uint16_t target_boost)
{
    set_var_wastegate_pos(wastegate);
    set_var_target_boost(target_boost);
    ui_update();
}

void update_tcu_status(uint8_t protection_flags)
{
    // Определение статуса на основе флагов
    int8_t status = 0;  // OK
    if (protection_flags & 0x20) status = 2;      // ERROR (Limp mode)
    else if (protection_flags & 0x0F) status = 1; // WARNING
    
    set_var_tcu_status(status);
    ui_update();
}
```

---

## 🎨 Расширенные возможности EEZ Studio

### Шаг 10: Добавление анимаций

**Timeline Editor для плавных переходов:**
1. Создайте Timeline для каждого датчика
2. Настройте easing functions (ease-in-out)
3. Добавьте keyframes для разных состояний:
   - Normal operation
   - Warning zone  
   - Error state
   - No data state

**Expression Builder для расчетов:**
```javascript
// MAP Pressure color calculation
if (map_pressure > 200) 
    return "#FF0000";  // Red - high pressure
else if (map_pressure > 180)
    return "#FFA500";  // Orange - warning
else 
    return "#00D4FF";  // Blue - normal

// RPM gauge color zones
if (engine_rpm > 6000)
    return "#FF0000";  // Red zone
else if (engine_rpm > 4500)
    return "#FFA500";  // Orange zone  
else
    return "#00FF00";  // Green zone
```

### Шаг 11: Multi-screen navigation

**Дополнительные экраны:**
1. **DiagnosticScreen** - детальная диагностика CAN
2. **SettingsScreen** - настройки отображения
3. **LoggingScreen** - запись данных на SD карту
4. **AlertScreen** - критические предупреждения

**Navigation flow:**
```
MainScreen ←→ DiagnosticScreen
     ↓
SettingsScreen ←→ LoggingScreen
     ↓
  AlertScreen (popup)
```

---

## 📋 Контрольный список миграции

### Pre-migration checklist:
```
☐ EEZ Studio установлена и протестирована  
☐ Текущий LVGL проект работает корректно
☐ Определена структура новых экранов
☐ Переменные и их типы задокументированы
```

### Migration steps:
```
☐ 1. Создан новый LVGL проект в EEZ Studio
☐ 2. Настроены размеры дисплея (800x480)  
☐ 3. Созданы 6 датчиков с правильными параметрами
☐ 4. Настроены цветовые схемы для каждого датчика
☐ 5. Определены глобальные переменные
☐ 6. Настроены анимации и переходы
☐ 7. Создана flow-логика для обработки данных
☐ 8. Экспортирован C++ код
☐ 9. Интегрирован код с ESP32-S3 проектом
☐ 10. Протестирована работа с реальными CAN данными
```

### Post-migration testing:
```
☐ Все датчики отображают корректные значения
☐ Анимации работают плавно (60Hz)
☐ Цветовые индикации срабатывают правильно  
☐ CAN сообщения обрабатываются без потерь
☐ Touch интерфейс отвечает корректно
☐ Система стабильна при длительной работе
```

---

## 🔍 Сравнение: SquareLine vs EEZ Studio

### SquareLine Studio:
- ✓ Проще в изучении
- ✓ Больше готовых виджетов
- ✓ Лучше для простых проектов
- ✗ Коммерческая лицензия
- ✗ Ограниченная кастомизация

### EEZ Studio:
- ✓ **Бесплатный и open source**
- ✓ **Flow-based программирование**  
- ✓ **Expression builder для сложной логики**
- ✓ **Встроенный отладчик**
- ✓ **Timeline анимации**
- ✓ **Multi-screen навигация**
- ✗ Более крутая кривая обучения
- ✗ Меньше готовых шаблонов

---

## 🎯 Заключение

**EEZ Studio идеально подходит для ECU Dashboard**, особенно если планируется:
- Расширение функциональности (диагностика, настройки)
- Более сложная логика обработки CAN данных  
- Профессиональный automotive интерфейс
- Долгосрочное развитие проекта

**Время миграции:** ~2-3 дня для опытного разработчика
**Результат:** Более мощный и гибкий ECU Dashboard

---

**Файл:** EEZ_STUDIO_MIGRATION_GUIDE.md  
**Версия:** 1.0  
**Дата:** 26 июля 2025  
**Совместимость:** EEZ Studio latest, ESP32-S3-Touch-LCD-7, LVGL 8.3